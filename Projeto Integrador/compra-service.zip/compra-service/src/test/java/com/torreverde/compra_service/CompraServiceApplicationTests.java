package com.torreverde.compra_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompraServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
